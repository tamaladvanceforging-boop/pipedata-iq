<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/**
 * One PipeDoc IQ logo everywhere: browser tab (favicon), app shell, wp-admin, login, front end.
 * If the site has no Site Icon set in Settings → General, the plugin's own icon files are used,
 * so a fresh install (or a copy on another host) never falls back to the WordPress "W".
 */
class PDQ_Brand {
	public static function init() {
		add_filter( 'get_site_icon_url', array( __CLASS__, 'site_icon_fallback' ), 10, 2 );
	}

	/** Icon file for a requested pixel size (nearest larger file). */
	public static function icon_url( $size = 32 ) {
		$size = (int) $size;
		foreach ( array( 32, 180, 192, 512 ) as $s ) { if ( $size <= $s ) { return PDQ_URL . 'assets/icons/icon-' . $s . '.png'; } }
		return PDQ_URL . 'assets/icons/icon-512.png';
	}

	public static function site_icon_fallback( $url, $size = 512 ) {
		return $url ? $url : self::icon_url( $size );
	}

	/** <link> tags for pages the plugin renders itself (they do not run wp_head). */
	public static function head_links() {
		$v = '?v=' . PDQ_VERSION;
		$site = get_option( 'site_icon' ) ? get_site_icon_url( 32 ) : '';
		$out  = '<link rel="icon" type="image/svg+xml" href="' . esc_url( PDQ_URL . 'assets/logo.svg' . $v ) . '">';
		$out .= '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $site ? $site : self::icon_url( 32 ) . $v ) . '">';
		$out .= '<link rel="apple-touch-icon" href="' . esc_url( get_site_icon_url( 180 ) ) . '">';
		$out .= '<meta name="theme-color" content="#18181b">';
		return $out;
	}
}
