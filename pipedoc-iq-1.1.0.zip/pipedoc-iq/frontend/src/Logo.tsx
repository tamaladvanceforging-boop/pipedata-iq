/** PipeDoc IQ mark: a pipe elbow feeding a document. Same artwork as assets/logo.svg, the favicon and the site icon. */
export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="PipeDoc IQ logo" style={{ display: 'block', flexShrink: 0 }}>
      <defs><linearGradient id="pdqg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#FB923C" /><stop offset="1" stopColor="#EA580C" /></linearGradient></defs>
      <rect width="64" height="64" rx="14" fill="url(#pdqg)" />
      <path d="M15 47V28a9 9 0 0 1 9-9h12" fill="none" stroke="#18181B" strokeWidth="9" />
      <rect x="8" y="43" width="14" height="7" rx="1.5" fill="#18181B" />
      <rect x="33" y="12" width="7" height="14" rx="1.5" fill="#18181B" />
      <path d="M34 30h14l6 6v16a3 3 0 0 1-3 3H34a3 3 0 0 1-3-3V33a3 3 0 0 1 3-3z" fill="#fff" />
      <path d="M48 30v6h6z" fill="#FDBA74" />
      <path d="M36 43h14M36 48h9" stroke="#EA580C" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}
export function Brand({ collapsed }: { collapsed?: boolean }) {
  return (<div className="flex items-center gap-2"><LogoMark />{!collapsed && <div className="leading-tight"><div className="font-head text-base font-extrabold">PipeDoc <span className="text-brand">IQ</span></div><div className="text-[10px] opacity-60">Engineering data → print-ready docs</div></div>}</div>);
}
